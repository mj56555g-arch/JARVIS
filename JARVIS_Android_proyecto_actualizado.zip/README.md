# JARVIS para Android

Proyecto Android inicial para generar un APK de prueba.

## Funciones incluidas
- Interfaz oscura estilo futurista.
- Reconocimiento de voz en español (usa el servicio de voz instalado en Android).
- Respuesta hablada mediante Text-to-Speech del teléfono.
- Comandos básicos: hora, cámara, ajustes, teléfono y saludo.

## Limitaciones importantes
- No tiene palabra de activación permanente ("Hey JARVIS").
- No escucha en segundo plano.
- No incluye todavía conexión a un modelo de IA ni control avanzado del dispositivo.
- La voz depende de las voces instaladas en Android; no reproduce exactamente la voz de la película.
- El reconocimiento de voz puede necesitar Internet según el motor instalado.

## Compilar
Requiere Android SDK y JDK 17. Desde la carpeta del proyecto:
`gradle assembleDebug`

El APK de prueba se genera en:
`app/build/outputs/apk/debug/app-debug.apk`

También incluye un flujo de GitHub Actions (`.github/workflows/build-apk.yml`) para compilar al subir el proyecto a un repositorio y ejecutar el flujo.
