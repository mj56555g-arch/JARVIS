package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private lateinit var answer: TextView
    private val micRequest = 77

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 11, 22)
        window.navigationBarColor = android.graphics.Color.rgb(5, 11, 22)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micRequest)
        } else initRecognizer()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(android.graphics.Color.rgb(5, 11, 22))
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 34f
            letterSpacing = 0.18f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(0, 217, 255))
        }
        status = TextView(this).apply {
            text = "SISTEMA EN ESPERA"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.LTGRAY)
            setPadding(0, 18, 0, 22)
        }
        answer = TextView(this).apply {
            text = "Hola. Soy JARVIS. Pulsa el botón y habla conmigo."
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setPadding(8, 20, 8, 30)
        }
        val listen = Button(this).apply {
            text = "ACTIVAR ESCUCHA"
            setOnClickListener { startListening() }
        }
        val help = Button(this).apply {
            text = "AYUDA"
            setOnClickListener { respond("Puedes preguntarme la hora o pedirme que abra la cámara, los ajustes o el teléfono.") }
        }
        root.addView(title)
        root.addView(status)
        root.addView(answer, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(listen, LinearLayout.LayoutParams(-1, -2))
        root.addView(help, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun initRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "TE ESCUCHO..." }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "PROCESANDO..." }
                override fun onError(error: Int) { status.text = "NO SE DETECTÓ LA VOZ. INTENTA OTRA VEZ." }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    answer.text = "Tú: $words"
                    handleCommand(words.lowercase(Locale.ROOT))
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        } else status.text = "RECONOCIMIENTO DE VOZ NO DISPONIBLE"
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micRequest)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla con JARVIS")
        }
        try { recognizer?.startListening(intent) ?: run { status.text = "No se pudo iniciar el micrófono" } }
        catch (_: Exception) { status.text = "Error al iniciar el reconocimiento" }
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("hora") -> {
                val now = SimpleDateFormat("HH:mm", Locale("es", "PY")).format(Date())
                respond("Son las $now.")
            }
            command.contains("cámara") || command.contains("camara") -> {
                respond("Abriendo la cámara.")
                runCatching { startActivity(Intent("android.media.action.IMAGE_CAPTURE")) }
            }
            command.contains("ajustes") || command.contains("configuración") -> {
                respond("Abriendo los ajustes.")
                runCatching { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
            }
            command.contains("teléfono") || command.contains("llamar") -> {
                respond("Abriendo el teléfono.")
                runCatching { startActivity(Intent(Intent.ACTION_DIAL)) }
            }
            command.contains("hola") -> respond("Hola. Estoy a tu servicio.")
            else -> respond("Todavía no tengo una respuesta para eso. Puedo decirte la hora, abrir la cámara, los ajustes o el teléfono.")
        }
    }

    private fun respond(message: String) {
        answer.text = message
        status.text = "JARVIS ACTIVO"
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("es", "MX"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("es"))
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == micRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) initRecognizer()
        else status.text = "SE NECESITA PERMISO DE MICRÓFONO"
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
